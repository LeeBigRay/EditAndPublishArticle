//
//  NSAttributedString+RichText.h
//  RichTextView
//
//  Created by 赵群涛 on 16/5/2.
//  Copyright © 2016年 愚非愚余. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSAttributedString (RichText)
//返回带有图片标示的字符串
- (NSString *)getPlainString;

//返回数组，每个数组是一种属性和对应的内容
-(NSMutableArray *)getArrayWithAttributed;

//获取颜色值
- (NSString *)getHexStringByColor:(UIColor *)originColor;
//获取有 rgb，alpha的字典
- (NSDictionary *)getRGBDictionaryByColor:(UIColor *)originColor;
@end
