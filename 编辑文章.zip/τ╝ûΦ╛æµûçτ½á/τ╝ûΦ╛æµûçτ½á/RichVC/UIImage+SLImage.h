//
//  UIImage+SLImage.h
//  HeShi
//
//  Created by apple on 16/1/4.
//  Copyright © 2016年 Oyd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (SLImage)
//缩放图片
- (UIImage *)scaleToSize:(CGSize)size;
@end
